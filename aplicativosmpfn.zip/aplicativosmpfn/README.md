# aplicativosmpfn
Recuperar todos los aplicativos mpfn de la carpeta prog
